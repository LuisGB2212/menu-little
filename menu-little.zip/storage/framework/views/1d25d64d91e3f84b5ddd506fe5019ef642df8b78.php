<table class="table table-responsive-lg table-hover">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Cantidad</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $drinkFoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drinkFood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <strong><?php echo e($drinkFood->drinkFood->name); ?></strong> <br>
                    <?php echo e($drinkFood->details); ?>

                </td>
                <td><?php echo e($drinkFood->quantity); ?></td>
                <td><?php echo e($drinkFood->price); ?></td>
                <td id="btnOrderServ<?php echo e($drinkFood->id); ?>">
                    <?php if($drinkFood->status == 'pendiente'): ?>
                        <button type="button" idDrinkFoodOrder="<?php echo e($drinkFood->id); ?>" class="btn btn-danger drinkFoodOrderServ">
                            Marcar como Servido
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-success">
                            <?php echo e($drinkFood->status); ?>

                        </button>
                        
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\wamp64\www\menu-light2\resources\views/backend/partitials/informationOrderFood.blade.php ENDPATH**/ ?>