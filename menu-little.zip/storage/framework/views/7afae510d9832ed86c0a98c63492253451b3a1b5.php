<?php $__env->startSection('content'); ?>
    <!--================ Menu Area =================-->
    <section class="menu_area section_gap">
        <div class="container">
            <div class="row menu_inner">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist" align="center">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e($key == 0 ? 'active' : ''); ?>" 
                                    id="home-tab" 
                                    data-toggle="tab"
                                    href="#data<?php echo e($type->id); ?>"
                                    role="tab"><?php echo e($type->type_name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e($key == 0 ? 'active' : ''); ?>" id="data<?php echo e($type->id); ?>" role="tabpanel">
                                <br>
                                <div class="row justify-content-center">
                                    <?php $__currentLoopData = $type->categoryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $par = $index%2;
                                        ?>
                                        <div class="col-lg-5 <?php echo e($par != 0 ? 'offset-1' : ''); ?>">
                                            <div class="menu_list">
                                                <h1><?php echo e($category->category->category_name); ?></h1>
                                                <ul class="list">
                                                    <?php $__currentLoopData = $category->category->drinkFoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drinkFood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <h4><?php echo e($drinkFood->name); ?>

                                                                <span>$<?php echo e(number_format($drinkFood->price,2,'.',',')); ?> <br>
                                                                <button class="btn btn-danger btn-sm addProductCar" idProduct="<?php echo e($drinkFood->id); ?>">
                                                                    <span class="text-custom">Agregar <i class="fa fa-plus"></i></span>
                                                                </button>
                                                                </span>
                                                            </h4>
                                                            <p>(<?php echo e($drinkFood->description); ?>)</p>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--================End Menu Area =================-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\menu-light2\resources\views/welcome.blade.php ENDPATH**/ ?>