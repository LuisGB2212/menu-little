

<?php $__env->startSection('content'); ?>
    <section class="menu_area section_gap">
        <div class="container">
            <div class="row menu_inner">
                <div class="col-lg-12">
                    <h1>Las Ordenes</h1><hr>
                    <form action="" id="orderProducts">
                        <table class="table table-responsive-lg">
                            <thead>
                                <tr align="center" class="bg-danger">
                                    <th colspan="5">
                                        <h2>Orden</h2>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Cantidad</th>
                                    <th>Precio Unitario</th>
                                    <th>Total</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="tableOrder">
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="item<?php echo e($item->id); ?>">
                                        <td>
                                            <strong><?php echo e($item->name); ?></strong>
                                            <br><?php echo e($item->options->details != null ? '('.$item->options->details.')' : ''); ?>

                                        </td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->total); ?></td>
                                        <td>
                                            <button class="btn btn-danger deleteItem" idItem="<?php echo e($item->id); ?>" idProduct="<?php echo e($item->rowId); ?>">
                                                <i class="fa fa-times"></i>
                                            </button>    
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                        <div class="col-lg-12 row" id="tableFooterOrder">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-10">
                                <?php if(!Request()->session()->has('table') && Cart::count() > 0): ?>
                                    <?php
                                        $typeOrders = \App\TypeOrder::all();
                                    ?>
                                    <div class="col-lg-12 row form-group" align="center">
                                        <div class="col-lg-12">
                                            <h4>No se encuentra en el local, para su pedido sera?</h4>
                                        </div>
                                        <?php
                                            $idType = 0;
                                            $checkTypeOrder = null;
                                            if(Request()->session()->has('order')){
                                                $idType = Request()->session()->get('order')['type_order_id'];
                                                $checkTypeOrder = $typeOrders->where('id',$idType)->first();
                                            }
                                        ?>
                                        
                                        <?php if($checkTypeOrder != null): ?>
                                            <div class="col-lg-12">
                                                <strong>Su orden se agregara al anterior, ya que no ha realizado el pagado</strong>
                                                <br>Modalidad: <?php echo e($checkTypeOrder->name); ?>

                                            </div>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $typeOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4">
                                                    <input type="radio" required class="" name="typeOrderId" value="<?php echo e($typeOrder->id); ?>"><?php echo e($typeOrder->name); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php echo $__env->make('frontend.informationUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-2">
                                <button type="submit" class="btn btn-danger btn-lg ">
                                    Ordenar <i class="fa fa-arrow-circle-right"></i>
                                </button>
                            </div>        
                        </div>
                    </form>
                </div>
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\menu-light2\resources\views/frontend/orders.blade.php ENDPATH**/ ?>