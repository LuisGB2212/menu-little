<div class="row justify-content-center">
    
    <table class="table table-responsive-lg table-hover table-striped">
        <thead>
            <tr>
                <th>
                    #
                </th>
                <th>
                    Numero de Orden
                </th>
                <th>
                    Mesa
                </th>
                <th>
                    Hora
                </th>
                <th>
                    Estatus de pago
                </th>
                <th>
                    Acciones
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($order->number_order); ?></td>
                    <td><?php echo e($order->table_id != null ? $order->table->name.' '.$order->table->number : $order->typeOrder->name); ?></td>
                    <td><?php echo e($order->created_at); ?></td>
                    <td>
                        <?php if($order->checkOrders->count() > 0): ?>
                            Pagado <br>
                            <strong><?php echo e($order->checkOrders[0]->payment_method); ?></strong>
                        <?php else: ?>
                            Pendiente
                        <?php endif; ?>
                    </td>
                    <td>
                        <button type="button" idOrder="<?php echo e($order->id); ?>" class="informationOrder btn btn-danger">
                            <i class="fa fa-eye"></i>
                        </button>
                        <?php if($order->status != 'cerrado'): ?>
                            <button type="button" idOrderUp="<?php echo e($order->id); ?>" class="orderUpdate btn btn-danger">
                                Cerrar Orden
                            </button
                        <?php endif; ?>
                        <?php if($order->checkOrders->count() < 1): ?>
                            <button type="button" totalToPay="<?php echo e($order->total()); ?>" idOrderToPay="<?php echo e($order->id); ?>" class="orderToAddPay btn btn-danger">
                                Cobrar
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\wamp64\www\menu-light2\resources\views/backend/partitials/tables.blade.php ENDPATH**/ ?>